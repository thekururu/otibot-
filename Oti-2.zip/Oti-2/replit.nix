{pkgs}: {
  deps = [
    pkgs.fly
   ];
}
